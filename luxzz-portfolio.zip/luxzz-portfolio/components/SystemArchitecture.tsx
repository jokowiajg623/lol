'use client'

import { motion } from 'framer-motion'

const layers = [
  {
    id: '01',
    title: 'Microservice Architecture',
    description:
      'Decomposed services communicating via lightweight protocols. Each service owns its data, enabling independent deployment and horizontal scaling without system-wide risk.',
    tags: ['Docker', 'Kubernetes', 'gRPC'],
  },
  {
    id: '02',
    title: 'REST API Design',
    description:
      'RESTful endpoints following OpenAPI spec, with JWT authentication, rate limiting, versioning, and comprehensive request/response validation baked in from day one.',
    tags: ['OpenAPI', 'JWT', 'Rate Limiting'],
  },
  {
    id: '03',
    title: 'Queue & Async Processing',
    description:
      'Asynchronous job processing via message queues. Tasks are dispatched, queued, and consumed independently — preventing bottlenecks and ensuring resilient data pipelines.',
    tags: ['RabbitMQ', 'Celery', 'Redis'],
  },
  {
    id: '04',
    title: 'Backend Infrastructure',
    description:
      'Infrastructure-as-code deployments with automated CI/CD pipelines, observability via distributed tracing and metrics, and zero-downtime rolling updates.',
    tags: ['Terraform', 'GitHub Actions', 'Prometheus'],
  },
]

export default function SystemArchitecture() {
  return (
    <section id="architecture" className="relative z-10 py-32 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section Label */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="flex items-center gap-4 mb-20"
        >
          <span className="font-mono text-xs tracking-[0.3em] uppercase text-[#39ff14]/60">
            04 / System Architecture
          </span>
          <div className="flex-1 h-px bg-gradient-to-r from-[#39ff14]/20 to-transparent" />
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Left: Heading */}
          <div className="lg:sticky lg:top-24">
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              viewport={{ once: true }}
              className="font-display text-4xl md:text-5xl font-bold text-white mb-6 leading-tight"
            >
              How I Design<br />
              <span className="text-[#39ff14]">Systems.</span>
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              viewport={{ once: true }}
              className="font-body text-white/40 leading-relaxed mb-8 text-sm"
            >
              My approach to software architecture emphasizes decoupling, fault tolerance,
              and observability. Every system I build is designed to evolve — components
              can scale, fail, and be replaced independently.
            </motion.p>

            {/* Diagram visual */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              viewport={{ once: true }}
              className="relative p-6 border border-[#1e1e1e] bg-[#0d0d0d]"
            >
              <p className="font-mono text-[10px] tracking-widest uppercase text-white/20 mb-5">
                System Flow
              </p>
              {/* ASCII-style diagram */}
              <div className="font-mono text-xs text-white/30 leading-loose space-y-1">
                <div>
                  <span className="text-[#39ff14]/60">[Client]</span>{' '}
                  → API Gateway → Load Balancer
                </div>
                <div className="pl-4 text-white/20">↓ Auth Middleware</div>
                <div className="pl-4">
                  → <span className="text-[#39ff14]/50">[Service A]</span> →{' '}
                  <span className="text-[#39ff14]/50">[Service B]</span>
                </div>
                <div className="pl-8 text-white/20">↓ Message Queue</div>
                <div className="pl-8">
                  → <span className="text-[#39ff14]/40">[Worker]</span> → Database
                </div>
                <div className="pl-12 text-white/20">↓ Cache Layer</div>
                <div className="pl-12">→ <span className="text-[#39ff14]/30">[Redis]</span></div>
              </div>
            </motion.div>
          </div>

          {/* Right: Cards */}
          <div className="space-y-4">
            {layers.map((layer, i) => (
              <motion.div
                key={layer.id}
                initial={{ opacity: 0, x: 40 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{
                  delay: i * 0.1,
                  duration: 0.6,
                  ease: [0.16, 1, 0.3, 1],
                }}
                viewport={{ once: true }}
                whileHover={{ x: 4 }}
                className="group relative p-6 border border-[#1e1e1e] hover:border-[#39ff14]/30 transition-all duration-400 bg-[#0d0d0d] cursor-default"
              >
                {/* Hover glow */}
                <div
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-400"
                  style={{
                    background: 'radial-gradient(ellipse at left, rgba(57,255,20,0.05) 0%, transparent 60%)',
                  }}
                />

                <div className="relative flex gap-5">
                  {/* Number */}
                  <div className="flex-shrink-0">
                    <span className="font-mono text-2xl font-bold text-[#39ff14]/15 group-hover:text-[#39ff14]/30 transition-colors duration-300">
                      {layer.id}
                    </span>
                  </div>

                  <div className="flex-1 min-w-0">
                    <h3 className="font-display text-base font-semibold text-white/80 group-hover:text-white mb-3 transition-colors duration-300">
                      {layer.title}
                    </h3>
                    <p className="font-body text-sm text-white/30 leading-relaxed mb-4">
                      {layer.description}
                    </p>
                    {/* Tech tags */}
                    <div className="flex flex-wrap gap-2">
                      {layer.tags.map((tag) => (
                        <span key={tag} className="tech-tag">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Left border accent on hover */}
                <motion.div
                  className="absolute left-0 top-4 bottom-4 w-px"
                  initial={false}
                  animate={{
                    background: 'linear-gradient(180deg, transparent, rgba(57,255,20,0.4), transparent)',
                    opacity: 0,
                  }}
                  whileHover={{ opacity: 1 }}
                  transition={{ duration: 0.3 }}
                />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
