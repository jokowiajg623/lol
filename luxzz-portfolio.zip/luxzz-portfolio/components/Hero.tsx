'use client'

import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'

const container = {
  hidden: {},
  show: {
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.3,
    },
  },
}

const item = {
  hidden: { opacity: 0, y: 60 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 1, ease: [0.16, 1, 0.3, 1] },
  },
}

export default function Hero() {
  const headlineRef = useRef<HTMLHeadingElement>(null)

  return (
    <section className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 text-center overflow-hidden">
      {/* Background radial center glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse 80% 50% at 50% 60%, rgba(57,255,20,0.04) 0%, transparent 70%)',
        }}
      />

      {/* Decorative corner marks */}
      <div className="absolute top-24 left-8 w-6 h-6 border-t border-l border-[#39ff14]/30" />
      <div className="absolute top-24 right-8 w-6 h-6 border-t border-r border-[#39ff14]/30" />
      <div className="absolute bottom-16 left-8 w-6 h-6 border-b border-l border-[#39ff14]/30" />
      <div className="absolute bottom-16 right-8 w-6 h-6 border-b border-r border-[#39ff14]/30" />

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="max-w-5xl mx-auto"
      >
        {/* Label */}
        <motion.div variants={item} className="mb-8">
          <span className="font-mono text-xs tracking-[0.3em] uppercase text-[#39ff14]/60 border border-[#39ff14]/20 px-4 py-2 inline-block">
            Portfolio 2025
          </span>
        </motion.div>

        {/* Headline */}
        <motion.h1
          ref={headlineRef}
          variants={item}
          className="font-display text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold leading-[0.9] tracking-tight mb-6"
        >
          <span className="block text-white">Welcome To</span>
          <span
            className="block"
            style={{
              background: 'linear-gradient(135deg, #ffffff 20%, #39ff14 60%, #a8ff78 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            Luxzz Portfolio
          </span>
        </motion.h1>

        {/* Divider */}
        <motion.div variants={item} className="flex items-center justify-center gap-4 mb-6">
          <div className="h-px w-12 bg-gradient-to-r from-transparent to-[#39ff14]/40" />
          <div className="w-1 h-1 rounded-full bg-[#39ff14]/60" />
          <div className="h-px w-12 bg-gradient-to-l from-transparent to-[#39ff14]/40" />
        </motion.div>

        {/* Subtitle */}
        <motion.p
          variants={item}
          className="font-body text-lg sm:text-xl md:text-2xl text-white/50 font-light tracking-widest uppercase mb-12"
        >
          Full Stack Developer
        </motion.p>

        {/* Description */}
        <motion.p
          variants={item}
          className="font-body text-sm sm:text-base text-white/30 max-w-xl mx-auto leading-relaxed mb-16"
        >
          Crafting robust backend systems, scalable APIs, and automation solutions
          with precision and elegance.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div variants={item} className="flex items-center justify-center gap-4 flex-wrap">
          <button
            onClick={() => {
              const el = document.querySelector('#projects')
              el?.scrollIntoView({ behavior: 'smooth' })
            }}
            className="relative group font-mono text-xs tracking-widest uppercase px-8 py-4 bg-[#39ff14] text-black font-bold hover:bg-white transition-all duration-300 overflow-hidden"
          >
            <span className="relative z-10">View Projects</span>
          </button>
          <button
            onClick={() => {
              const el = document.querySelector('#contact')
              el?.scrollIntoView({ behavior: 'smooth' })
            }}
            className="font-mono text-xs tracking-widest uppercase px-8 py-4 border border-[#39ff14]/30 text-white/60 hover:text-[#39ff14] hover:border-[#39ff14]/70 transition-all duration-300"
          >
            Get In Touch
          </button>
        </motion.div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.8, duration: 0.8 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3"
      >
        <span className="font-mono text-[10px] tracking-[0.4em] uppercase text-white/25">Scroll</span>
        <div className="relative w-px h-12 bg-white/10 overflow-hidden">
          <motion.div
            className="absolute top-0 left-0 w-full bg-gradient-to-b from-[#39ff14]/60 to-transparent"
            initial={{ height: '0%', top: '-100%' }}
            animate={{ height: '50%', top: ['−100%', '200%'] }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              ease: 'linear',
              repeatDelay: 0.5,
            }}
          />
        </div>
      </motion.div>
    </section>
  )
}
