'use client'

import { motion } from 'framer-motion'

const scripts = [
  { name: 'Nmap', category: 'Network Scanner' },
  { name: 'Wireshark', category: 'Packet Analyzer' },
  { name: 'Metasploit', category: 'Exploitation' },
  { name: 'Burp Suite', category: 'Web Proxy' },
  { name: 'Aircrack-ng', category: 'Wireless' },
  { name: 'Hydra', category: 'Brute Force' },
  { name: 'John the Ripper', category: 'Password Cracker' },
  { name: 'Nikto', category: 'Web Scanner' },
  { name: 'Gobuster', category: 'Directory Enum' },
  { name: 'Sqlmap', category: 'SQL Injection' },
]

export default function Scripts() {
  return (
    <section id="scripts" className="relative z-10 py-32 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section Label */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="flex items-center gap-4 mb-20"
        >
          <span className="font-mono text-xs tracking-[0.3em] uppercase text-[#39ff14]/60">
            02 / Favorite Scripts
          </span>
          <div className="flex-1 h-px bg-gradient-to-r from-[#39ff14]/20 to-transparent" />
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          viewport={{ once: true }}
          className="font-display text-3xl md:text-4xl font-bold text-white mb-4"
        >
          Security <span className="text-[#39ff14]">Arsenal</span>
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          viewport={{ once: true }}
          className="font-body text-white/30 text-sm mb-16 max-w-md"
        >
          Tools I use for network analysis, penetration testing, and security research.
        </motion.p>

        {/* Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
          {scripts.map((script, i) => (
            <motion.div
              key={script.name}
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              transition={{
                delay: i * 0.06,
                duration: 0.5,
                ease: [0.16, 1, 0.3, 1],
              }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.03, y: -2 }}
              className="group relative cursor-default"
            >
              <div
                className="relative p-4 border border-[#1e1e1e] group-hover:border-[#39ff14]/40 transition-all duration-400 overflow-hidden"
                style={{ background: '#0d0d0d' }}
              >
                {/* Glow on hover */}
                <div
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-400"
                  style={{
                    background: 'radial-gradient(ellipse at center, rgba(57,255,20,0.08) 0%, transparent 70%)',
                  }}
                />
                {/* Top accent line */}
                <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#39ff14]/0 to-transparent group-hover:via-[#39ff14]/40 transition-all duration-500" />

                <div className="relative">
                  {/* Index */}
                  <p className="font-mono text-[10px] text-[#39ff14]/20 group-hover:text-[#39ff14]/50 transition-colors duration-300 mb-3 tracking-widest">
                    {String(i + 1).padStart(2, '0')}
                  </p>
                  {/* Name */}
                  <p className="font-display text-sm font-semibold text-white/70 group-hover:text-white transition-colors duration-300 leading-tight mb-1">
                    {script.name}
                  </p>
                  {/* Category */}
                  <p className="font-mono text-[10px] text-white/20 group-hover:text-[#39ff14]/40 transition-colors duration-300 tracking-wider uppercase">
                    {script.category}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
