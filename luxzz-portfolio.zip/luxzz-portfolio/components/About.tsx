'use client'

import Image from 'next/image'
import { motion } from 'framer-motion'
import { useInView } from './useInView'

const techStack = [
  { name: 'JavaScript', icon: 'JS' },
  { name: 'Laravel', icon: 'LV' },
  { name: 'Python', icon: 'PY' },
  { name: 'C++', icon: 'C++' },
  { name: 'Java', icon: 'JV' },
  { name: 'Golang', icon: 'GO' },
]

const timeline = [
  {
    year: '2024 – Present',
    role: 'Senior Full Stack Developer',
    desc: 'Architecting microservice-based systems, building high-performance REST APIs, and leading backend infrastructure.',
  },
  {
    year: '2022 – 2024',
    role: 'Backend Engineer',
    desc: 'Developed scalable server-side applications using Laravel and Golang, integrated third-party services and automated workflows.',
  },
  {
    year: '2020 – 2022',
    role: 'Junior Developer',
    desc: 'Built web applications, learned system design patterns, and contributed to open-source projects.',
  },
]

function TechCard({ name, icon, delay }: { name: string; icon: string; delay: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      whileInView={{ opacity: 1, scale: 1 }}
      transition={{ delay, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      viewport={{ once: true }}
      whileHover={{ scale: 1.05 }}
      className="group relative flex flex-col items-center justify-center gap-2 p-5 border border-[#1e1e1e] hover:border-[#39ff14]/40 transition-all duration-400 cursor-default"
      style={{
        background: 'linear-gradient(135deg, #111111 0%, #0d0d0d 100%)',
      }}
    >
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-400"
        style={{
          background: 'radial-gradient(ellipse at center, rgba(57,255,20,0.06) 0%, transparent 70%)',
          boxShadow: 'inset 0 0 20px rgba(57,255,20,0.04)',
        }}
      />
      <span className="font-mono text-lg font-bold text-[#39ff14]/70 group-hover:text-[#39ff14] transition-colors duration-300">
        {icon}
      </span>
      <span className="font-body text-xs text-white/40 group-hover:text-white/70 transition-colors duration-300 tracking-wider">
        {name}
      </span>
    </motion.div>
  )
}

export default function About() {
  const { ref, inView } = useInView()

  return (
    <section id="about" className="relative z-10 py-32 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section Label */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="flex items-center gap-4 mb-20"
        >
          <span className="font-mono text-xs tracking-[0.3em] uppercase text-[#39ff14]/60">
            01 / About
          </span>
          <div className="flex-1 h-px bg-gradient-to-r from-[#39ff14]/20 to-transparent" />
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-start">
          {/* Left: Profile */}
          <div>
            {/* Profile Image */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              viewport={{ once: true }}
              className="relative mb-12 inline-block"
            >
              <div className="relative w-64 h-64 md:w-80 md:h-80">
                <div
                  className="absolute inset-0 border border-[#39ff14]/20"
                  style={{ transform: 'translate(8px, 8px)' }}
                />
                <div className="relative w-full h-full overflow-hidden border border-[#1e1e1e] bg-[#111]">
                  <Image
                    src="/images/profile/profile.jpg"
                    alt="Luxzz – Full Stack Developer"
                    fill
                    className="object-cover grayscale hover:grayscale-0 transition-all duration-700"
                    sizes="(max-width: 768px) 256px, 320px"
                    onError={(e) => {
                      // Fallback if image not found
                      const target = e.target as HTMLImageElement
                      target.style.display = 'none'
                    }}
                  />
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a]/60 to-transparent" />
                  {/* Placeholder shown when no image */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="font-display text-5xl font-bold text-[#39ff14]/20">LX</span>
                  </div>
                </div>
                {/* Corner accents */}
                <div className="absolute -top-2 -left-2 w-4 h-4 border-t-2 border-l-2 border-[#39ff14]/60" />
                <div className="absolute -top-2 -right-2 w-4 h-4 border-t-2 border-r-2 border-[#39ff14]/60" />
                <div className="absolute -bottom-2 -left-2 w-4 h-4 border-b-2 border-l-2 border-[#39ff14]/60" />
                <div className="absolute -bottom-2 -right-2 w-4 h-4 border-b-2 border-r-2 border-[#39ff14]/60" />
              </div>
            </motion.div>

            {/* Tech Stack */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <p className="font-mono text-xs tracking-widest uppercase text-white/25 mb-6">
                Tech Stack
              </p>
              <div className="grid grid-cols-3 gap-3">
                {techStack.map((tech, i) => (
                  <TechCard key={tech.name} {...tech} delay={i * 0.07} />
                ))}
              </div>
            </motion.div>
          </div>

          {/* Right: Bio + Timeline */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
              viewport={{ once: true }}
              className="mb-12"
            >
              <h2 className="font-display text-4xl md:text-5xl font-bold text-white mb-8 leading-tight">
                Building Systems<br />
                <span className="text-[#39ff14]">That Scale.</span>
              </h2>

              <div className="space-y-5 text-white/50 font-body leading-relaxed">
                <p>
                  I&apos;m a Full Stack Developer with deep expertise in backend architecture,
                  system design, and automation. I specialize in building high-performance
                  applications that handle complex business logic with clarity and precision.
                </p>
                <p>
                  My approach blends clean code principles with pragmatic engineering —
                  whether architecting microservices with Golang, building REST APIs in Laravel,
                  or scripting automation workflows in Python. I thrive in environments
                  that demand technical depth.
                </p>
                <p>
                  When I&apos;m not writing code, I explore security tooling, network analysis,
                  and low-level system internals — always pushing the boundaries of what I know.
                </p>
              </div>
            </motion.div>

            {/* Timeline */}
            <div ref={ref}>
              <p className="font-mono text-xs tracking-widest uppercase text-white/25 mb-8">
                Experience
              </p>
              <div className="relative pl-6">
                <div className="timeline-line" />
                <div className="space-y-10">
                  {timeline.map((item, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.15, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                      viewport={{ once: true }}
                      className="relative"
                    >
                      {/* Dot */}
                      <div className="absolute -left-[25px] top-1 w-2 h-2 rounded-full border border-[#39ff14]/60 bg-[#0a0a0a]" />
                      <p className="font-mono text-xs text-[#39ff14]/60 tracking-widest mb-1.5">
                        {item.year}
                      </p>
                      <h4 className="font-display text-base font-semibold text-white mb-2">
                        {item.role}
                      </h4>
                      <p className="font-body text-sm text-white/35 leading-relaxed">
                        {item.desc}
                      </p>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
