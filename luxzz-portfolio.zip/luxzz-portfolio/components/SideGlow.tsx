'use client'

export default function SideGlow() {
  return (
    <>
      <div className="glow-left" />
      <div className="glow-right" />
    </>
  )
}
