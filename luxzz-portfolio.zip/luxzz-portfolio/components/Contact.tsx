'use client'

import { motion } from 'framer-motion'

const socials = [
  {
    name: 'Instagram',
    handle: '@luxzz.dev',
    href: 'https://www.instagram.com/luxzz.dev',
    description: 'Behind the build. Process & updates.',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-6 h-6">
        <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
        <circle cx="12" cy="12" r="5" />
        <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
      </svg>
    ),
  },
  {
    name: 'TikTok',
    handle: '@luxzz.dev',
    href: 'https://www.tiktok.com/@luxzz.dev',
    description: 'Tech content & coding sessions.',
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
        <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.32 6.32 0 00-.79-.05A6.34 6.34 0 003.15 15.3a6.34 6.34 0 006.34 6.35 6.34 6.34 0 006.33-6.35V8.69a8.17 8.17 0 004.78 1.52V6.76a4.85 4.85 0 01-1.01-.07z" />
      </svg>
    ),
  },
]

export default function Contact() {
  return (
    <section id="contact" className="relative z-10 py-32 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section Label */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="flex items-center gap-4 mb-20"
        >
          <span className="font-mono text-xs tracking-[0.3em] uppercase text-[#39ff14]/60">
            05 / Contact
          </span>
          <div className="flex-1 h-px bg-gradient-to-r from-[#39ff14]/20 to-transparent" />
        </motion.div>

        <div className="text-center mb-20">
          <motion.h2
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            viewport={{ once: true }}
            className="font-display text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight"
          >
            Let&apos;s{' '}
            <span className="text-[#39ff14]">Connect.</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            viewport={{ once: true }}
            className="font-body text-white/30 text-sm max-w-md mx-auto"
          >
            Follow along on social media for behind-the-scenes content, tech insights,
            and updates on what I&apos;m building.
          </motion.p>
        </div>

        {/* Social Cards */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-6 max-w-2xl mx-auto">
          {socials.map((social, i) => (
            <motion.a
              key={social.name}
              href={social.href}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 40, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              transition={{
                delay: i * 0.15,
                duration: 0.7,
                ease: [0.16, 1, 0.3, 1],
              }}
              viewport={{ once: true }}
              whileHover={{ y: -6, scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="group relative w-full sm:w-72 p-8 border border-[#1e1e1e] hover:border-[#39ff14]/40 transition-all duration-400 cursor-pointer overflow-hidden"
              style={{ background: '#0d0d0d' }}
            >
              {/* Hover glow */}
              <motion.div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                style={{
                  background: 'radial-gradient(ellipse at top, rgba(57,255,20,0.08) 0%, transparent 70%)',
                }}
              />

              {/* Top border glow on hover */}
              <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#39ff14]/0 to-transparent group-hover:via-[#39ff14]/50 transition-all duration-500" />

              <div className="relative">
                {/* Icon */}
                <div className="mb-6 text-white/25 group-hover:text-[#39ff14]/70 transition-colors duration-400 w-fit">
                  {social.icon}
                </div>

                {/* Name */}
                <h3 className="font-display text-xl font-bold text-white/80 group-hover:text-white mb-1 transition-colors duration-300">
                  {social.name}
                </h3>

                {/* Handle */}
                <p className="font-mono text-xs text-[#39ff14]/40 group-hover:text-[#39ff14]/70 transition-colors duration-300 mb-4 tracking-wider">
                  {social.handle}
                </p>

                {/* Description */}
                <p className="font-body text-sm text-white/25 group-hover:text-white/45 transition-colors duration-300">
                  {social.description}
                </p>

                {/* Arrow indicator */}
                <div className="mt-6 flex items-center gap-2 text-[#39ff14]/0 group-hover:text-[#39ff14]/60 transition-all duration-400">
                  <span className="font-mono text-[10px] tracking-widest uppercase">
                    Follow
                  </span>
                  <svg className="w-3 h-3 group-hover:translate-x-1 transition-transform duration-300" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <path d="M1 6h10M7 2l4 4-4 4" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
              </div>
            </motion.a>
          ))}
        </div>

        {/* Bottom decoration */}
        <motion.div
          initial={{ opacity: 0, scaleX: 0 }}
          whileInView={{ opacity: 1, scaleX: 1 }}
          transition={{ duration: 1, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-24 line-accent"
        />
      </div>
    </section>
  )
}
