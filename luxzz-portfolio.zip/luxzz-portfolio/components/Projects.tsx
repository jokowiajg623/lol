'use client'

import Image from 'next/image'
import { motion } from 'framer-motion'
import { useState } from 'react'

const projects = [
  {
    id: 1,
    title: 'MicroAPI Gateway',
    category: 'Backend',
    tags: ['Backend', 'API'],
    description:
      'High-performance API gateway built with Golang. Handles authentication, rate limiting, and request routing across microservices.',
    image: '/images/projects/projects1.png',
    tech: ['Golang', 'Redis', 'Docker', 'Nginx'],
  },
  {
    id: 2,
    title: 'AutoFlow Engine',
    category: 'Automation',
    tags: ['Automation', 'System'],
    description:
      'Intelligent automation pipeline processing 10k+ events per second using Python, Celery, and RabbitMQ queue systems.',
    image: '/images/projects/projects2.png',
    tech: ['Python', 'Celery', 'RabbitMQ', 'PostgreSQL'],
  },
  {
    id: 3,
    title: 'Laravel CMS Platform',
    category: 'Backend',
    tags: ['Backend', 'API'],
    description:
      'Enterprise-grade content management system with multi-tenant architecture, REST API, and role-based access control.',
    image: '/images/projects/projects3.png',
    tech: ['Laravel', 'MySQL', 'Redis', 'JWT'],
  },
  {
    id: 4,
    title: 'Distributed Task Runner',
    category: 'System',
    tags: ['System', 'Automation'],
    description:
      'Distributed job scheduler built for fault tolerance and horizontal scaling across multiple nodes and cloud providers.',
    image: '/images/projects/projects4.png',
    tech: ['Golang', 'Kubernetes', 'gRPC', 'Prometheus'],
  },
]

const tagColors: Record<string, string> = {
  Backend: 'rgba(57,255,20,0.12)',
  API: 'rgba(57,255,20,0.08)',
  Automation: 'rgba(57,255,20,0.1)',
  System: 'rgba(57,255,20,0.06)',
}

function ProjectCard({ project, index }: { project: typeof projects[0]; index: number }) {
  const [hovered, setHovered] = useState(false)

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{
        delay: index * 0.12,
        duration: 0.7,
        ease: [0.16, 1, 0.3, 1],
      }}
      viewport={{ once: true }}
      onHoverStart={() => setHovered(true)}
      onHoverEnd={() => setHovered(false)}
      className="group relative cursor-default"
    >
      <motion.div
        className="relative overflow-hidden border border-[#1e1e1e] transition-all duration-500"
        animate={{
          borderColor: hovered ? 'rgba(57,255,20,0.35)' : 'rgba(30,30,30,1)',
          boxShadow: hovered
            ? '0 0 30px rgba(57,255,20,0.08), 0 20px 60px rgba(0,0,0,0.5)'
            : '0 0 0 rgba(57,255,20,0)',
        }}
        transition={{ duration: 0.4 }}
      >
        {/* Image container */}
        <div className="relative h-52 overflow-hidden bg-[#111]">
          <motion.div
            className="absolute inset-0"
            animate={{ scale: hovered ? 1.07 : 1 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          >
            <Image
              src={project.image}
              alt={project.title}
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 50vw"
              onError={(e) => {
                const parent = (e.target as HTMLElement).parentElement?.parentElement
                if (parent) {
                  parent.style.background = '#111111'
                }
              }}
            />
          </motion.div>

          {/* Cinematic gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/40 to-transparent" />

          {/* Hover glow overlay */}
          <motion.div
            className="absolute inset-0"
            animate={{
              background: hovered
                ? 'radial-gradient(ellipse at center, rgba(57,255,20,0.06) 0%, transparent 70%)'
                : 'transparent',
            }}
            transition={{ duration: 0.4 }}
          />

          {/* Tags on image */}
          <div className="absolute top-3 left-3 flex gap-2">
            {project.tags.map((tag) => (
              <span key={tag} className="tech-tag text-[10px]">
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 bg-[#0d0d0d]">
          <h3 className="font-display text-lg font-bold text-white mb-2 group-hover:text-[#39ff14] transition-colors duration-300">
            {project.title}
          </h3>
          <p className="font-body text-sm text-white/35 leading-relaxed mb-5">
            {project.description}
          </p>

          {/* Tech pills */}
          <div className="flex flex-wrap gap-2">
            {project.tech.map((t) => (
              <span
                key={t}
                className="font-mono text-[10px] tracking-wider px-2 py-1 text-white/30 border border-white/8 uppercase"
              >
                {t}
              </span>
            ))}
          </div>
        </div>

        {/* Top accent line on hover */}
        <motion.div
          className="absolute top-0 left-0 h-px"
          animate={{
            width: hovered ? '100%' : '0%',
            background: 'linear-gradient(90deg, #39ff14, transparent)',
          }}
          transition={{ duration: 0.4 }}
        />
      </motion.div>
    </motion.div>
  )
}

export default function Projects() {
  return (
    <section id="projects" className="relative z-10 py-32 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section Label */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="flex items-center gap-4 mb-20"
        >
          <span className="font-mono text-xs tracking-[0.3em] uppercase text-[#39ff14]/60">
            03 / Projects
          </span>
          <div className="flex-1 h-px bg-gradient-to-r from-[#39ff14]/20 to-transparent" />
        </motion.div>

        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            viewport={{ once: true }}
            className="font-display text-3xl md:text-5xl font-bold text-white"
          >
            Selected<br />
            <span className="text-[#39ff14]">Work.</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15 }}
            viewport={{ once: true }}
            className="font-body text-sm text-white/30 max-w-xs"
          >
            Systems built for performance, reliability, and scale.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {projects.map((project, i) => (
            <ProjectCard key={project.id} project={project} index={i} />
          ))}
        </div>
      </div>
    </section>
  )
}
