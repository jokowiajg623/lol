'use client'

import dynamic from 'next/dynamic'
import { useEffect } from 'react'
import Hero from '@/components/Hero'
import About from '@/components/About'
import Scripts from '@/components/Scripts'
import Projects from '@/components/Projects'
import SystemArchitecture from '@/components/SystemArchitecture'
import Contact from '@/components/Contact'
import Navbar from '@/components/Navbar'
import SideGlow from '@/components/SideGlow'

const ParticlesBackground = dynamic(() => import('@/components/ParticlesBackground'), {
  ssr: false,
})

export default function Home() {
  useEffect(() => {
    // Initialize Lenis smooth scroll
    const initLenis = async () => {
      const Lenis = (await import('lenis')).default
      const lenis = new Lenis({
        duration: 1.4,
        easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        smoothWheel: true,
      })

      function raf(time: number) {
        lenis.raf(time)
        requestAnimationFrame(raf)
      }
      requestAnimationFrame(raf)

      return () => {
        lenis.destroy()
      }
    }

    const cleanup = initLenis()
    return () => {
      cleanup.then((fn) => fn?.())
    }
  }, [])

  return (
    <main className="relative min-h-screen bg-[#0a0a0a] overflow-x-hidden">
      {/* Fixed background elements */}
      <ParticlesBackground />
      <SideGlow />

      {/* Navigation */}
      <Navbar />

      {/* Sections */}
      <Hero />
      <About />
      <Scripts />
      <Projects />
      <SystemArchitecture />
      <Contact />

      {/* Footer */}
      <footer className="relative z-10 border-t border-[#1e1e1e] py-8">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="font-mono text-xs text-white/20 tracking-widest uppercase">
            © 2025 Luxzz Portfolio
          </p>
          <div className="line-accent w-32 hidden md:block" />
          <p className="font-mono text-xs text-white/20 tracking-widest uppercase">
            Full Stack Developer
          </p>
        </div>
      </footer>
    </main>
  )
}
