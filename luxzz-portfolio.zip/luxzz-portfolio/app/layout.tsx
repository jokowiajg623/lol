import type { Metadata } from 'next'
import '../styles/globals.css'

export const metadata: Metadata = {
  title: 'Welcome To Luxzz Portfolio | Full Stack Developer',
  description:
    'Full Stack Developer specializing in backend systems, APIs, automation, and modern web architecture. Building premium digital experiences.',
  keywords: [
    'Full Stack Developer',
    'Backend Developer',
    'Laravel',
    'Golang',
    'Python',
    'JavaScript',
    'Portfolio',
    'Luxzz',
  ],
  authors: [{ name: 'Luxzz' }],
  creator: 'Luxzz',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    title: 'Welcome To Luxzz Portfolio | Full Stack Developer',
    description:
      'Full Stack Developer specializing in backend systems, APIs, and automation.',
    siteName: 'Luxzz Portfolio',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  themeColor: '#0a0a0a',
  viewport: 'width=device-width, initial-scale=1',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>{children}</body>
    </html>
  )
}
