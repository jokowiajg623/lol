# Luxzz Portfolio

> Full Stack Developer Portfolio — Premium, Modern, Futuristic

Built with **Next.js 14 App Router**, **Framer Motion**, **GSAP**, **Lenis**, and **tsParticles**.

---

## 🚀 Tech Stack

| Technology | Purpose |
|---|---|
| Next.js 14 (App Router) | Framework |
| TypeScript | Type Safety |
| Tailwind CSS | Styling |
| Framer Motion | Animations & Transitions |
| Lenis | Smooth Scrolling |
| tsParticles | Particle Background |

---

## 📦 Dependencies

```json
{
  "next": "14.2.5",
  "react": "18.3.1",
  "react-dom": "18.3.1",
  "framer-motion": "^11.3.24",
  "@tsparticles/react": "^3.0.0",
  "@tsparticles/slim": "^3.5.0",
  "lenis": "^1.1.13",
  "clsx": "^2.1.1"
}
```

---

## 📁 Project Structure

```
luxzz-portfolio/
├── app/
│   ├── layout.tsx         # Root layout + metadata
│   └── page.tsx           # Main page (all sections)
├── components/
│   ├── Navbar.tsx
│   ├── Hero.tsx
│   ├── About.tsx
│   ├── Scripts.tsx
│   ├── Projects.tsx
│   ├── SystemArchitecture.tsx
│   ├── Contact.tsx
│   ├── ParticlesBackground.tsx
│   ├── SideGlow.tsx
│   └── useInView.ts
├── styles/
│   └── globals.css
├── public/
│   └── images/
│       ├── profile/
│       │   └── profile.jpg   ← Replace with your photo
│       └── projects/
│           ├── projects1.png  ← Replace with project screenshots
│           ├── projects2.png
│           ├── projects3.png
│           └── projects4.png
├── package.json
├── next.config.js
├── tailwind.config.js
├── tsconfig.json
└── .eslintrc.json
```

---

## ⚡ Getting Started

### 1. Install Dependencies

```bash
npm install
```

### 2. Add Your Images

Replace placeholder images:
- `public/images/profile/profile.jpg` — Your profile photo
- `public/images/projects/projects1.png` → `projects4.png` — Project screenshots

### 3. Customize Content

Edit these files:
- `components/About.tsx` — Bio, tech stack, timeline
- `components/Projects.tsx` — Project titles, descriptions
- `components/Contact.tsx` — Your TikTok & Instagram URLs

### 4. Run Locally

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## 🏗️ Build for Production

```bash
npm run build
npm start
```

---

## ☁️ Deploy to Vercel

### Option A: CLI (Recommended)

```bash
npm i -g vercel
vercel
```

Follow the prompts — no additional configuration needed.

### Option B: GitHub + Vercel Dashboard

1. Push to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Import your repository
4. Click **Deploy** — done!

Vercel auto-detects Next.js and configures everything automatically.

---

## 🎨 Customization

### Colors
Edit `styles/globals.css` CSS variables:
```css
--neon: #39ff14;       /* Accent green */
--bg: #0a0a0a;         /* Background */
```

### Social Links
Edit `components/Contact.tsx`:
```tsx
href: 'https://www.instagram.com/YOUR_USERNAME',
href: 'https://www.tiktok.com/@YOUR_USERNAME',
```

### Fonts
Loaded from Google Fonts in `styles/globals.css`:
- **Syne** — Display/heading font
- **DM Sans** — Body text
- **JetBrains Mono** — Monospace/code

---

## 📈 Performance

- ✅ Image optimization via next/image
- ✅ Dynamic imports (particles loaded client-side only)
- ✅ CSS-first animations where possible
- ✅ Proper `once: true` on all scroll animations
- ✅ SEO metadata via Next.js Metadata API

---

© 2025 Luxzz Portfolio
